title: "我的第一篇博客"
date: 2014-12-08 16:27:39
tags: [博客，测试]
---


这是我的第一篇博客


第二段啦，是不是啊。

*第三段*
**第三段中部**

#一级标题
##二级标题

大标题
=

小标题
-



> 这是引用


java#





    public class Test{
	String result = "";
	if(null != result){
		result = "true";
	}
	}

新浪博客地址: [我的新浪博客](http://weibo.com/u/1709380933/home?wvr=5)

![这是一个Logo图像](http://old.xmsogo.com/upfile/2008/3/26/200832692022305.jpg)

![AI photo](https://raw.githubusercontent.com/aheadlcx/learngit/master/ai.jpg)