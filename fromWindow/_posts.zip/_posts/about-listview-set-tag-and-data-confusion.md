title: about listview set tag and data confusion
date: 2014-12-10 14:43:51
tags:
---

#关于listview中setTag的使用

情景 A，listview中的edittext，编写写入数据，必须先给edittext设置tag，再给添加个listener，记录下来数据，改变实体的值。
